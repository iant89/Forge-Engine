import { faceUVToDirection } from '../cubeSphere';
import { sampleAnalytic, WorldGenParams } from '../terrain/analyticBase';
import { thermalErode } from '../erosion/thermal';
import { computeD8Flow, carveByFlow } from '../erosion/hydraulic';
import { sampleWindDelta, WindConfig } from '../erosion/wind';
import { GeoMaterial } from '../geology/materials';

export interface GlobalFaceFields {
  face: number;
  res: number;
  baseElevation: Float32Array;   // analytic elevation, before simulated erosion (debug/reference)
  erodedElevation: Float32Array; // after thermal + hydraulic + wind passes
  erosionDelta: Float32Array;    // erodedElevation - baseElevation; this is what Stage B adds
  hardness: Float32Array;
  material: Uint8Array;
  flowAccum: Float32Array;
}

export interface StageAOptions {
  res: number;                 // grid resolution per cube face (res x res)
  thermalIterations: number;
  thermalTalusDeg: number;
  hydraulicIncision: number;
  hydraulicAccumPower: number;
  wind: WindConfig;
}

// Stage A: one low-resolution simulation pass per cube face. Craters/volcanoes/dichotomy are
// analytic and could in principle be evaluated at any resolution directly, but erosion is a
// grid-relaxation process (each cell's result depends on its neighbors), so it has to be
// simulated once on a bounded grid and then cached — chunk generation (Stage B) later
// interpolates this cached `erosionDelta` field rather than re-simulating anything.
export function runStageAForFace(face: number, params: WorldGenParams, opts: StageAOptions): GlobalFaceFields {
  const { res } = opts;
  const baseElevation = new Float32Array(res * res);
  const hardness = new Float32Array(res * res);
  const material = new Uint8Array(res * res);
  const flowAccum = new Float32Array(res * res);

  for (let j = 0; j < res; j++) {
    for (let i = 0; i < res; i++) {
      const u = (i / (res - 1)) * 2 - 1, v = (j / (res - 1)) * 2 - 1;
      const dir = faceUVToDirection(face, u, v);
      const s = sampleAnalytic(dir, params);
      const idx = j * res + i;
      baseElevation[idx] = s.elevation;
      hardness[idx] = s.hardness;
      material[idx] = s.material;
    }
  }

  const erodedElevation = Float32Array.from(baseElevation);

  // Approximate meters-per-cell for this face's grid (cube-sphere distortion means this is only
  // approximate — acceptable for a coarse erosion simulation; do not use it for exact geometry).
  const approxCellSize = (Math.PI / 2 * params.radius) / res;

  const talusTan = Math.tan(opts.thermalTalusDeg * Math.PI / 180);
  thermalErode(erodedElevation, res, res, talusTan, opts.thermalIterations, approxCellSize);

  const { flowAccum: fa } = computeD8Flow(erodedElevation, res, res);
  flowAccum.set(fa);
  carveByFlow(erodedElevation, res, res, flowAccum, hardness, opts.hydraulicIncision, opts.hydraulicAccumPower);

  for (let j = 0; j < res; j++) {
    for (let i = 0; i < res; i++) {
      const idx = j * res + i;
      const u = (i / (res - 1)) * 2 - 1, v = (j / (res - 1)) * 2 - 1;
      const dir = faceUVToDirection(face, u, v);
      const isLoose = material[idx] === GeoMaterial.Regolith || material[idx] === GeoMaterial.DuneField;
      erodedElevation[idx] += sampleWindDelta(dir, params.radius, isLoose, opts.wind);
      if (isLoose && flowAccum[idx] < res * 0.5) material[idx] = GeoMaterial.DuneField;
    }
  }

  const erosionDelta = new Float32Array(res * res);
  for (let i = 0; i < res * res; i++) erosionDelta[i] = erodedElevation[i] - baseElevation[i];

  return { face, res, baseElevation, erodedElevation, erosionDelta, hardness, material, flowAccum };
}
