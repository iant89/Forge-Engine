import { Vec3 } from '../utils/vec3';
import { directionToFaceUV } from '../cubeSphere';
import { GlobalFaceFields } from './stageA';

export interface GlobalSample { erosionDelta: number; hardness: number; material: number; flowAccum: number; }

// Bilinear-samples the cached Stage A fields for whichever face/uv a direction falls on. Chunk
// generation calls this once per vertex to pick up the large-scale simulated-erosion correction
// and geology context alongside the analytic (point-wise) terrain.
export function sampleGlobalFields(dir: Vec3, faces: GlobalFaceFields[]): GlobalSample {
  const { face, u, v } = directionToFaceUV(dir);
  const f = faces[face];
  const res = f.res;
  const fx = ((u + 1) / 2) * (res - 1);
  const fy = ((v + 1) / 2) * (res - 1);
  const x0 = Math.max(0, Math.min(res - 2, Math.floor(fx)));
  const y0 = Math.max(0, Math.min(res - 2, Math.floor(fy)));
  const tx = fx - x0, ty = fy - y0;

  const at = (arr: Float32Array | Uint8Array, x: number, y: number) => arr[y * res + x];
  const bilerp = (arr: Float32Array | Uint8Array) => {
    const a = at(arr, x0, y0), b = at(arr, x0 + 1, y0), c = at(arr, x0, y0 + 1), d = at(arr, x0 + 1, y0 + 1);
    return (a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty;
  };

  return {
    erosionDelta: bilerp(f.erosionDelta),
    hardness: bilerp(f.hardness),
    material: at(f.material, Math.round(fx), Math.round(fy)), // nearest-neighbor for discrete ids
    flowAccum: bilerp(f.flowAccum),
  };
}
