import * as fs from 'fs';
import * as path from 'path';
import { GlobalFaceFields } from './stageA';

// One field per file, one directory per face. This is deliberately simple (no manual byte-offset
// packing) so there is no risk of TypedArray alignment bugs when reading fields back.
function writeF32(file: string, arr: Float32Array) { fs.writeFileSync(file, Buffer.from(arr.buffer, arr.byteOffset, arr.byteLength)); }
function writeU8(file: string, arr: Uint8Array) { fs.writeFileSync(file, Buffer.from(arr.buffer, arr.byteOffset, arr.byteLength)); }

function readF32(file: string, count: number): Float32Array {
  const buf = fs.readFileSync(file);
  const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength); // fresh, 0-based ArrayBuffer
  return new Float32Array(ab, 0, count);
}
function readU8(file: string, count: number): Uint8Array {
  const buf = fs.readFileSync(file);
  return new Uint8Array(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength), 0, count);
}

export function saveGlobalFace(dir: string, f: GlobalFaceFields) {
  const faceDir = path.join(dir, `face_${f.face}`);
  fs.mkdirSync(faceDir, { recursive: true });
  fs.writeFileSync(path.join(faceDir, 'meta.json'), JSON.stringify({ face: f.face, res: f.res }));
  writeF32(path.join(faceDir, 'baseElevation.f32'), f.baseElevation);
  writeF32(path.join(faceDir, 'erodedElevation.f32'), f.erodedElevation);
  writeF32(path.join(faceDir, 'erosionDelta.f32'), f.erosionDelta);
  writeF32(path.join(faceDir, 'hardness.f32'), f.hardness);
  writeU8(path.join(faceDir, 'material.u8'), f.material);
  writeF32(path.join(faceDir, 'flowAccum.f32'), f.flowAccum);
}

export function loadGlobalFace(dir: string, face: number): GlobalFaceFields {
  const faceDir = path.join(dir, `face_${face}`);
  const meta = JSON.parse(fs.readFileSync(path.join(faceDir, 'meta.json'), 'utf8'));
  const res: number = meta.res;
  const n = res * res;
  return {
    face, res,
    baseElevation: readF32(path.join(faceDir, 'baseElevation.f32'), n),
    erodedElevation: readF32(path.join(faceDir, 'erodedElevation.f32'), n),
    erosionDelta: readF32(path.join(faceDir, 'erosionDelta.f32'), n),
    hardness: readF32(path.join(faceDir, 'hardness.f32'), n),
    material: readU8(path.join(faceDir, 'material.u8'), n),
    flowAccum: readF32(path.join(faceDir, 'flowAccum.f32'), n),
  };
}
