import { WorldGenParams } from '../terrain/analyticBase';
import { normalize, scale } from '../utils/vec3';
import { StageAOptions } from '../global/stageA';

export const MARS_RADIUS_M = 3_389_500;
export const MARS_GRAVITY = 3.71; // m/s^2 — lower gravity than Earth supports steeper stable slopes

export const marsParams: WorldGenParams = {
  seed: 1337,
  radius: MARS_RADIUS_M,
  dichotomy: {
    seed: 1337,
    axis: normalize({ x: 0.2, y: 0.95, z: 0.1 }), // arbitrary "highland pole" direction — replace to taste
    boundaryOffset: 0.15,
    amplitude: 4000, // meters of dichotomy relief (Mars' real north/south dichotomy is a few km)
    waviness: 0.3,
  },
  canyon: [
    // A simplified Valles-Marineris-like rift as a chain of segments. Replace with real
    // start/end points (and add more segments) to trace an actual canyon path.
    {
      a: { x: MARS_RADIUS_M * 0.6, y: MARS_RADIUS_M * 0.3, z: MARS_RADIUS_M * 0.7 },
      b: { x: MARS_RADIUS_M * 0.9, y: MARS_RADIUS_M * 0.1, z: MARS_RADIUS_M * 0.4 },
      width: 100_000, depth: 6000,
    },
  ],
  volcanoes: [
    // An Olympus-Mons-like shield: real Olympus Mons is ~600km across and ~21km tall.
    {
      center: scale(normalize({ x: -0.3, y: 0.5, z: 0.8 }), MARS_RADIUS_M),
      baseRadius: 300_000, height: 21_000, calderaRadius: 40_000, calderaDepth: 3000, seed: 42,
    },
  ],
};

export const stageAOptions: StageAOptions = {
  res: 512,                 // per-face low-res simulation grid; raise for a more detailed global erosion pattern
  thermalIterations: 25,
  thermalTalusDeg: 32,      // loosely tuned angle of repose for a basalt/regolith mix
  hydraulicIncision: 0.4,
  hydraulicAccumPower: 0.5,
  wind: {
    seed: 99,
    axis: normalize({ x: 1, y: 0, z: 0 }), // simplified single prevailing-wind direction
    duneFrequency: 0.0006,
    duneAmplitude: 15,
  },
};
