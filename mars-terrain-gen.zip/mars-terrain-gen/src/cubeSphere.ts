import { Vec3, normalize } from './utils/vec3';

// Standard 6-face cube-sphere parameterization: the whole planet is covered by 6 quadtrees (one
// per cube face), each with local coordinates (u,v) in [-1,1]. This avoids the pole-singularity
// and pinching distortion an equirectangular (lat/long) projection would have, and is the same
// approach used by most planet-scale terrain systems.
export const FACE_PX = 0, FACE_NX = 1, FACE_PY = 2, FACE_NY = 3, FACE_PZ = 4, FACE_NZ = 5;

export function faceUVToDirection(face: number, u: number, v: number): Vec3 {
  let p: Vec3;
  switch (face) {
    case FACE_PX: p = { x: 1, y: v, z: -u }; break;
    case FACE_NX: p = { x: -1, y: v, z: u }; break;
    case FACE_PY: p = { x: u, y: 1, z: -v }; break;
    case FACE_NY: p = { x: u, y: -1, z: v }; break;
    case FACE_PZ: p = { x: u, y: v, z: 1 }; break;
    case FACE_NZ: p = { x: -u, y: v, z: -1 }; break;
    default: throw new Error('bad face: ' + face);
  }
  // "Spherified cube" warp (Cignoni et al.) — distributes area far more evenly across a face than
  // a naive normalize() would, which matters for keeping noise frequency roughly consistent
  // whether a chunk sits at a face center or a face corner.
  const { x, y, z } = p;
  const x2 = x * x, y2 = y * y, z2 = z * z;
  const sx = x * Math.sqrt(1 - y2 / 2 - z2 / 2 + (y2 * z2) / 3);
  const sy = y * Math.sqrt(1 - z2 / 2 - x2 / 2 + (z2 * x2) / 3);
  const sz = z * Math.sqrt(1 - x2 / 2 - y2 / 2 + (x2 * y2) / 3);
  return normalize({ x: sx, y: sy, z: sz });
}

// Approximate inverse of the above: given a direction, which face/uv does it fall nearest to.
// Used only to look up the correct low-res cell in the cached Stage A grids (see
// global/sampleGlobal.ts) — the spherify warp is not exactly inverted here, which is an
// acceptable approximation for that lookup but should not be relied on for exact geometry.
export function directionToFaceUV(dir: Vec3): { face: number; u: number; v: number } {
  const ax = Math.abs(dir.x), ay = Math.abs(dir.y), az = Math.abs(dir.z);
  if (ax >= ay && ax >= az) {
    const face = dir.x > 0 ? FACE_PX : FACE_NX;
    const u = dir.x > 0 ? -dir.z / ax : dir.z / ax;
    const v = dir.y / ax;
    return { face, u, v };
  } else if (ay >= ax && ay >= az) {
    const face = dir.y > 0 ? FACE_PY : FACE_NY;
    const u = dir.x / ay;
    const v = dir.y > 0 ? -dir.z / ay : dir.z / ay;
    return { face, u, v };
  } else {
    const face = dir.z > 0 ? FACE_PZ : FACE_NZ;
    const u = dir.z > 0 ? dir.x / az : -dir.x / az;
    const v = dir.y / az;
    return { face, u, v };
  }
}
