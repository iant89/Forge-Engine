import { Vec3, scale } from '../utils/vec3';
import { sampleCraterDelta } from '../geology/craters3';
import { sampleVolcanoDelta, sampleCinderCones, VolcanoDef } from '../geology/volcanic3';
import { sampleRegionalBase, DichotomyConfig, CanyonSegment } from '../geology/dichotomy3';
import { GeoMaterial, MATERIAL_HARDNESS } from '../geology/materials';
import { fbm3 } from '../noise/gradient3';

export interface WorldGenParams {
  seed: number;
  radius: number;
  dichotomy: DichotomyConfig;
  canyon: CanyonSegment[];
  volcanoes: VolcanoDef[];
}

export interface AnalyticSample { elevation: number; material: GeoMaterial; hardness: number; }

// Evaluates everything that can be computed directly from a point on the sphere, with no
// neighborhood/grid context: dichotomy + craters + volcanoes + broad regional fbm, plus a
// material/hardness classification. This is deliberately *analytic* (point-wise, embarrassingly
// parallel) so it can be evaluated identically at low-res (Stage A) or full chunk res (Stage B)
// without needing to resample or upscale anything. What it excludes is simulated erosion, which
// is inherently a grid-relaxation process — see global/stageA.ts for that piece.
export function sampleAnalytic(dirUnit: Vec3, params: WorldGenParams): AnalyticSample {
  const p = scale(dirUnit, params.radius);

  const regional = sampleRegionalBase(p, params.radius, params.dichotomy, params.canyon);
  const craters = sampleCraterDelta(p, params.seed);
  const volcano = sampleVolcanoDelta(p, params.volcanoes);
  const cones = sampleCinderCones(p, params.seed + 3);

  const elevation = regional + craters.delta + volcano + cones;

  let material: GeoMaterial;
  if (craters.inCrater) {
    material = GeoMaterial.CraterFloor;
  } else if (volcano > 200) {
    material = GeoMaterial.VolcanicFlank;
  } else if (regional < -1500) {
    material = GeoMaterial.LayeredSediment; // canyon floors / deep basins
  } else {
    const patch = fbm3(p.x * 0.00003, p.y * 0.00003, p.z * 0.00003, { octaves: 3, lacunarity: 2, gain: 0.5, frequency: 1, seed: params.seed + 77 });
    material = patch > 0.3 ? GeoMaterial.Regolith : GeoMaterial.ExposedBedrock;
  }

  return { elevation, material, hardness: MATERIAL_HARDNESS[material] };
}
