import { Vec3 } from '../utils/vec3';
import { fbm3 } from '../noise/gradient3';

export interface WindConfig { seed: number; axis: Vec3; duneFrequency: number; duneAmplitude: number; }

// Aeolian (wind) processes are one of the dominant *active* erosion/deposition forces on
// present-day Mars (unlike liquid water). This is a deliberately simple stand-in: `axis`
// represents a single simplified global prevailing-wind direction rather than a real
// atmospheric/pressure simulation, and dunes only form where the surface is already loose
// material and relatively flat — see README for how to extend this with real windward/leeward
// exposure and multiple wind regimes.
export function sampleWindDelta(dirUnit: Vec3, radius: number, geologyIsLoose: boolean, cfg: WindConfig): number {
  if (!geologyIsLoose) return 0;
  const p = { x: dirUnit.x * radius, y: dirUnit.y * radius, z: dirUnit.z * radius };
  const n = fbm3(p.x * cfg.duneFrequency, p.y * cfg.duneFrequency, p.z * cfg.duneFrequency, {
    octaves: 3, lacunarity: 2.2, gain: 0.5, frequency: 1, seed: cfg.seed + 41,
  });
  return n * cfg.duneAmplitude;
}
