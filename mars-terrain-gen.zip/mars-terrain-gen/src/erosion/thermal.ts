// Thermal (talus) erosion: iteratively moves material from any cell to a lower neighbor whenever
// the slope between them exceeds the material's angle of repose, simulating rockfall/debris
// creep. Produces talus slopes and smoothed, "settled" hillsides. Operates in-place on a flat
// row-major heightfield.
export function thermalErode(
  heights: Float32Array, width: number, height: number,
  talusAngleTan: number, iterations: number, cellSize: number, amount = 0.5
) {
  const dh = new Float32Array(heights.length);
  const nbrs: [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, 1], [1, -1], [-1, -1]];

  for (let it = 0; it < iterations; it++) {
    dh.fill(0);
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const i = y * width + x;
        const h = heights[i];
        let maxExcess = 0, targetIdx = -1;
        for (const [ox, oy] of nbrs) {
          const nx = x + ox, ny = y + oy;
          if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
          const j = ny * width + nx;
          const dist = (ox !== 0 && oy !== 0) ? Math.SQRT2 * cellSize : cellSize;
          const drop = h - heights[j];
          const maxStable = talusAngleTan * dist;
          const excess = drop - maxStable;
          if (excess > maxExcess) { maxExcess = excess; targetIdx = j; }
        }
        if (targetIdx >= 0) {
          const move = maxExcess * 0.5 * amount;
          dh[i] -= move;
          dh[targetIdx] += move;
        }
      }
    }
    for (let i = 0; i < heights.length; i++) heights[i] += dh[i];
  }
}
