// Simplified D8 flow-direction + flow-accumulation, and a one-time incision pass driven by it.
//
// This models Mars' hydrology as *frozen ancient history* rather than an active water cycle:
// there is no ongoing rainfall loop, just a single carve proportional to how much of the terrain
// drains through each cell (a reasonable simplification for present-day Mars' dry outflow
// channels/valley networks, which is what we're aiming to resemble).
export interface HydroResult { flowDir: Int8Array; flowAccum: Float32Array; }

const D8: [number, number][] = [[1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1]];

export function computeD8Flow(heights: Float32Array, width: number, height: number): HydroResult {
  const flowDir = new Int8Array(width * height).fill(-1);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = y * width + x;
      let best = -1, bestSlope = 0;
      for (let d = 0; d < 8; d++) {
        const [ox, oy] = D8[d];
        const nx = x + ox, ny = y + oy;
        if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
        const j = ny * width + nx;
        const dist = (ox !== 0 && oy !== 0) ? Math.SQRT2 : 1;
        const slope = (heights[i] - heights[j]) / dist;
        if (slope > bestSlope) { bestSlope = slope; best = d; }
      }
      flowDir[i] = best;
    }
  }

  // Accumulate by visiting cells from highest to lowest elevation, pushing each cell's
  // accumulated flow into whichever downhill neighbor it drains to.
  const order = Array.from({ length: width * height }, (_, i) => i).sort((a, b) => heights[b] - heights[a]);
  const flowAccum = new Float32Array(width * height).fill(1);
  for (const i of order) {
    const d = flowDir[i];
    if (d < 0) continue;
    const x = i % width, y = Math.floor(i / width);
    const [ox, oy] = D8[d];
    const nx = x + ox, ny = y + oy;
    if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
    flowAccum[ny * width + nx] += flowAccum[i];
  }
  return { flowDir, flowAccum };
}

export function carveByFlow(
  heights: Float32Array, width: number, height: number,
  flowAccum: Float32Array, hardness: Float32Array,
  incisionStrength: number, accumPower: number
) {
  for (let i = 0; i < heights.length; i++) {
    const power = Math.pow(flowAccum[i], accumPower);
    const resist = 0.3 + 0.7 * hardness[i]; // harder rock resists incision more
    heights[i] -= (incisionStrength * power) / resist;
  }
}
