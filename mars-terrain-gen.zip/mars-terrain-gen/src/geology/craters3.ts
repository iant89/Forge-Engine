import { Vec3, dist as v3dist } from '../utils/vec3';
import { hash3 } from '../noise/hash';

export interface CraterScale {
  cellSizeMeters: number; minRadius: number; maxRadius: number;
  maxDepthRatio: number; rimHeightRatio: number;
}

// Three size bands loosely modeled on real Mars crater populations: huge ancient basins
// (Hellas/Argyre-scale), medium craters, and abundant small craters for close-up detail.
export const MARS_CRATER_SCALES: CraterScale[] = [
  { cellSizeMeters: 500_000, minRadius: 40_000, maxRadius: 220_000, maxDepthRatio: 0.05, rimHeightRatio: 0.015 },
  { cellSizeMeters: 50_000, minRadius: 3_000, maxRadius: 20_000, maxDepthRatio: 0.12, rimHeightRatio: 0.06 },
  { cellSizeMeters: 5_000, minRadius: 150, maxRadius: 1_800, maxDepthRatio: 0.18, rimHeightRatio: 0.09 },
];

function craterProfile(distNorm: number, depthRatio: number, rimHeightRatio: number, centralPeak: boolean, age: number): number {
  const rimSharpness = 1 - age * 0.7; // older craters have softer, more degraded rims
  if (distNorm <= 1) {
    const bowl = -depthRatio * (1 - distNorm * distNorm) * (0.6 + 0.4 * rimSharpness);
    let peak = 0;
    if (centralPeak && distNorm < 0.25) peak = depthRatio * 0.5 * (1 - distNorm / 0.25) * rimSharpness;
    const rimBump = distNorm > 0.75 ? rimHeightRatio * Math.sin(((distNorm - 0.75) / 0.25) * Math.PI) * rimSharpness : 0;
    return bowl + peak + rimBump;
  } else if (distNorm < 2.2) {
    const t = (distNorm - 1) / 1.2;
    return rimHeightRatio * (1 - t) * (1 - t) * 0.5 * rimSharpness; // ejecta blanket falloff
  }
  return 0;
}

// One jittered crater-center candidate per 3D grid cell, hashed from the cell index + seed. Most
// cells contain no crater (kept sparse via the density hash) so craters cluster irregularly
// rather than sitting on a visible grid.
function cellCraterCandidate(cix: number, ciy: number, ciz: number, cellSize: number, seed: number): { center: Vec3; id: number } | null {
  const density = hash3(cix, ciy, ciz, seed * 7 + 1);
  if (density > 0.55) return null;
  const jx = (hash3(cix, ciy, ciz, seed * 7 + 2) - 0.5) * cellSize;
  const jy = (hash3(cix, ciy, ciz, seed * 7 + 3) - 0.5) * cellSize;
  const jz = (hash3(cix, ciy, ciz, seed * 7 + 4) - 0.5) * cellSize;
  const center: Vec3 = { x: (cix + 0.5) * cellSize + jx, y: (ciy + 0.5) * cellSize + jy, z: (ciz + 0.5) * cellSize + jz };
  const id = Math.floor(hash3(cix, ciy, ciz, seed * 7 + 5) * 1e9);
  return { center, id };
}

export function sampleCraterDelta(p: Vec3, seed: number): { delta: number; inCrater: boolean; craterId: number } {
  let delta = 0, inCrater = false, craterId = 0;
  for (const scale of MARS_CRATER_SCALES) {
    const cs = scale.cellSizeMeters;
    const cix = Math.floor(p.x / cs), ciy = Math.floor(p.y / cs), ciz = Math.floor(p.z / cs);
    for (let ox = -1; ox <= 1; ox++) for (let oy = -1; oy <= 1; oy++) for (let oz = -1; oz <= 1; oz++) {
      const cand = cellCraterCandidate(cix + ox, ciy + oy, ciz + oz, cs, seed ^ (cs | 0));
      if (!cand) continue;
      const radius = scale.minRadius + hash3(cand.id, 0, 0, seed) * (scale.maxRadius - scale.minRadius);
      const d = v3dist(p, cand.center);
      const distNorm = d / radius;
      if (distNorm < 2.2) {
        const age = hash3(cand.id, 1, 0, seed);
        const centralPeak = radius > 8000 && hash3(cand.id, 2, 0, seed) > 0.5;
        const depthRatio = scale.maxDepthRatio * (0.6 + 0.4 * hash3(cand.id, 3, 0, seed));
        const rimHeightRatio = scale.rimHeightRatio * (0.6 + 0.4 * hash3(cand.id, 4, 0, seed));
        delta += craterProfile(distNorm, depthRatio, rimHeightRatio, centralPeak, age) * radius;
        if (distNorm < 1) { inCrater = true; craterId = cand.id; }
      }
    }
  }
  return { delta, inCrater, craterId };
}
