import { Vec3, dot, sub, normalize } from '../utils/vec3';
import { fbm3, domainWarp3 } from '../noise/gradient3';

export interface DichotomyConfig {
  seed: number;
  axis: Vec3;             // unit vector: the "highland pole" of the north/south dichotomy boundary
  boundaryOffset: number; // -1..1, shifts the boundary great-circle off the axis's equator
  amplitude: number;      // meters of relief between lowlands and highlands
  waviness: number;
}

export interface CanyonSegment { a: Vec3; b: Vec3; width: number; depth: number; }

// The single broadest terrain feature: Mars' real crustal dichotomy (smooth young lowlands vs.
// heavily cratered ancient highlands) is modeled as a warped great-circle boundary, plus a very
// low-frequency regional fbm on top, plus an optional canyon system (Valles-Marineris-style rift).
export function sampleRegionalBase(p: Vec3, radius: number, cfg: DichotomyConfig, canyon: CanyonSegment[]): number {
  const dir = normalize(p);
  const [wx, wy, wz] = domainWarp3(dir.x * 4, dir.y * 4, dir.z * 4, cfg.seed, 0.25, 0.5);
  const wander = fbm3(wx, wy, wz, { octaves: 4, lacunarity: 2, gain: 0.5, frequency: 0.6, seed: cfg.seed + 1 }) * cfg.waviness;
  const latitudeLike = dot(dir, cfg.axis) - cfg.boundaryOffset + wander;
  let base = Math.tanh(latitudeLike * 3) * cfg.amplitude * 0.5;

  base += fbm3(dir.x * 6, dir.y * 6, dir.z * 6, { octaves: 5, lacunarity: 2.0, gain: 0.5, frequency: 1, seed: cfg.seed + 2 }) * cfg.amplitude * 0.2;

  for (const seg of canyon) base += sampleCanyonSegment(p, seg, cfg.seed);
  return base;
}

function sampleCanyonSegment(p: Vec3, seg: CanyonSegment, seed: number): number {
  const ab = sub(seg.b, seg.a);
  const len2 = dot(ab, ab) || 1;
  let t = dot(sub(p, seg.a), ab) / len2;
  t = Math.max(0, Math.min(1, t));
  const closest: Vec3 = { x: seg.a.x + ab.x * t, y: seg.a.y + ab.y * t, z: seg.a.z + ab.z * t };
  const d = Math.hypot(p.x - closest.x, p.y - closest.y, p.z - closest.z);
  const widthNoise = 1 + fbm3(p.x * 0.00004, p.y * 0.00004, p.z * 0.00004, { octaves: 3, lacunarity: 2, gain: 0.5, frequency: 1, seed: seed + 9 }) * 0.4;
  const w = seg.width * widthNoise;
  if (d > w) return 0;
  const dn = d / w;
  let depth = -seg.depth * (1 - Math.pow(dn, 2.2)); // steep-walled canyon cross-section
  depth += Math.sin(dn * Math.PI * 3) * seg.depth * 0.03 * (1 - dn); // subtle terrace shelves
  const endFade = Math.min(1, Math.min(t, 1 - t) * 8); // fade out at the ends of the rift axis
  return depth * endFade;
}
