export enum GeoMaterial {
  BasaltLowland = 0,
  LayeredSediment = 1,
  VolcanicFlank = 2,
  CraterEjecta = 3,
  CraterFloor = 4,
  Regolith = 5,
  DuneField = 6,
  PolarIce = 7,
  ExposedBedrock = 8,
  ChannelFloor = 9,
}

// Base rock hardness per material, 0..1 (higher = more erosion-resistant). Drives both the
// simulated erosion passes (Stage A) and the fine procedural detail amplitude (Stage B).
export const MATERIAL_HARDNESS: Record<GeoMaterial, number> = {
  [GeoMaterial.BasaltLowland]: 0.75,
  [GeoMaterial.LayeredSediment]: 0.35,
  [GeoMaterial.VolcanicFlank]: 0.6,
  [GeoMaterial.CraterEjecta]: 0.4,
  [GeoMaterial.CraterFloor]: 0.5,
  [GeoMaterial.Regolith]: 0.15,
  [GeoMaterial.DuneField]: 0.05,
  [GeoMaterial.PolarIce]: 0.2,
  [GeoMaterial.ExposedBedrock]: 0.9,
  [GeoMaterial.ChannelFloor]: 0.3,
};
