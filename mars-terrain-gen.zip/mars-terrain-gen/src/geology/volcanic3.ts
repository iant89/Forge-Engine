import { Vec3, dist as v3dist } from '../utils/vec3';
import { fbm3 } from '../noise/gradient3';

export interface VolcanoDef {
  center: Vec3; baseRadius: number; height: number; calderaRadius: number; calderaDepth: number; seed: number;
}

// Broad shield-volcano profile (Olympus Mons-style: enormous footprint, gentle flanks, summit
// caldera). Volcano positions/sizes are data-driven (placed explicitly by the designer via
// config/marsConfig.ts) rather than procedurally scattered — real volcanic provinces cluster
// around mantle plumes, which this generator doesn't simulate; flank texture and the caldera
// itself are procedural.
export function sampleVolcanoDelta(p: Vec3, volcanoes: VolcanoDef[]): number {
  let delta = 0;
  for (const v of volcanoes) {
    const d = v3dist(p, v.center);
    if (d > v.baseRadius * 1.3) continue;
    const t = d / v.baseRadius;
    let h = v.height * Math.pow(Math.max(0, 1 - t), 1.6);
    const calderaT = d / v.calderaRadius;
    if (calderaT < 1) h -= v.calderaDepth * (1 - calderaT * calderaT);
    const flow = fbm3(p.x * 0.00005, p.y * 0.00005, p.z * 0.00005, { octaves: 4, lacunarity: 2.1, gain: 0.5, frequency: 1, seed: v.seed + 500 });
    h += flow * v.height * 0.02 * Math.max(0, 1 - t); // lava-flow-lobe roughness on the flanks
    delta += h;
  }
  return delta;
}

// Sparse small cinder cones scattered through volcanic provinces — cheap grid-cell bumps rather
// than a full scale-band crater-style system, since they're a minor decorative feature here.
export function sampleCinderCones(p: Vec3, seed: number): number {
  const cell = 8000;
  const cix = Math.floor(p.x / cell), ciy = Math.floor(p.y / cell), ciz = Math.floor(p.z / cell);
  let delta = 0;
  for (let ox = -1; ox <= 1; ox++) for (let oy = -1; oy <= 1; oy++) for (let oz = -1; oz <= 1; oz++) {
    const gx = cix + ox, gy = ciy + oy, gz = ciz + oz;
    const h0 = ((gx * 928371 + gy * 68917 + gz * 127931 + seed * 7) >>> 0) % 1000 / 1000;
    if (h0 > 0.985) {
      const px = (gx + 0.5) * cell, py = (gy + 0.5) * cell, pz = (gz + 0.5) * cell;
      const r = 300 + h0 * 900;
      const height = 60 + h0 * 180;
      const d = v3dist(p, { x: px, y: py, z: pz });
      if (d < r) delta += height * Math.pow(1 - d / r, 2);
    }
  }
  return delta;
}
