import { hash3 } from './hash';

function fade(t: number) { return t * t * t * (t * (t * 6 - 15) + 10); }
function lerp(a: number, b: number, t: number) { return a + (b - a) * t; }

// 12 fixed gradient directions (cube-edge midpoints) — classic Perlin gradient set. Which one is
// used at each lattice point is chosen by hash rather than a permutation table, so it stays
// seed-parameterized and works at arbitrary (not just small) integer coordinates.
const GRADS: [number, number, number][] = [
  [1, 1, 0], [-1, 1, 0], [1, -1, 0], [-1, -1, 0],
  [1, 0, 1], [-1, 0, 1], [1, 0, -1], [-1, 0, -1],
  [0, 1, 1], [0, -1, 1], [0, 1, -1], [0, -1, -1],
];

function gradAt(ix: number, iy: number, iz: number, seed: number): [number, number, number] {
  const idx = Math.floor(hash3(ix, iy, iz, seed) * GRADS.length) % GRADS.length;
  return GRADS[idx];
}

export function perlin3(x: number, y: number, z: number, seed: number): number {
  const x0 = Math.floor(x), y0 = Math.floor(y), z0 = Math.floor(z);
  const x1 = x0 + 1, y1 = y0 + 1, z1 = z0 + 1;
  const sx = x - x0, sy = y - y0, sz = z - z0;

  const dotGrad = (ix: number, iy: number, iz: number) => {
    const g = gradAt(ix, iy, iz, seed);
    return g[0] * (x - ix) + g[1] * (y - iy) + g[2] * (z - iz);
  };

  const n000 = dotGrad(x0, y0, z0), n100 = dotGrad(x1, y0, z0);
  const n010 = dotGrad(x0, y1, z0), n110 = dotGrad(x1, y1, z0);
  const n001 = dotGrad(x0, y0, z1), n101 = dotGrad(x1, y0, z1);
  const n011 = dotGrad(x0, y1, z1), n111 = dotGrad(x1, y1, z1);

  const u = fade(sx), v = fade(sy), w = fade(sz);

  const nx00 = lerp(n000, n100, u), nx10 = lerp(n010, n110, u);
  const nx01 = lerp(n001, n101, u), nx11 = lerp(n011, n111, u);
  const nxy0 = lerp(nx00, nx10, v), nxy1 = lerp(nx01, nx11, v);
  return lerp(nxy0, nxy1, w); // ~[-1,1]
}

export interface Fbm3Options { octaves: number; lacunarity: number; gain: number; frequency: number; seed: number; }

export function fbm3(x: number, y: number, z: number, opts: Fbm3Options): number {
  let freq = opts.frequency, amp = 1, sum = 0, norm = 0;
  for (let o = 0; o < opts.octaves; o++) {
    sum += perlin3(x * freq, y * freq, z * freq, opts.seed + o * 101) * amp;
    norm += amp;
    freq *= opts.lacunarity;
    amp *= opts.gain;
  }
  return sum / norm; // ~[-1,1]
}

// Ridged multifractal: folds noise around zero so ridges (rather than smooth hills) dominate.
// Used for sharp meso/micro erosion texture (gullies, exposed rock edges).
export function ridged3(x: number, y: number, z: number, opts: Fbm3Options): number {
  let freq = opts.frequency, amp = 1, sum = 0, norm = 0;
  for (let o = 0; o < opts.octaves; o++) {
    const n = 1 - Math.abs(perlin3(x * freq, y * freq, z * freq, opts.seed + o * 131));
    sum += n * n * amp;
    norm += amp;
    freq *= opts.lacunarity;
    amp *= opts.gain;
  }
  return sum / norm; // [0,1]
}

export function domainWarp3(x: number, y: number, z: number, seed: number, strength: number, freq: number): [number, number, number] {
  const wx = fbm3(x, y, z, { octaves: 4, lacunarity: 2.0, gain: 0.5, frequency: freq, seed: seed + 7 });
  const wy = fbm3(x + 31.7, y - 17.3, z + 11.1, { octaves: 4, lacunarity: 2.0, gain: 0.5, frequency: freq, seed: seed + 13 });
  const wz = fbm3(x - 9.4, y + 5.2, z - 21.6, { octaves: 4, lacunarity: 2.0, gain: 0.5, frequency: freq, seed: seed + 19 });
  return [x + wx * strength, y + wy * strength, z + wz * strength];
}
