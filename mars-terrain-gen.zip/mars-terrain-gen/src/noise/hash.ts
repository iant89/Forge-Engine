// Deterministic integer hashing. Every procedural random decision in this generator is derived
// from (world position or id, seed) through these functions, so results are fully reproducible
// and continuous across chunk/face boundaries (no per-chunk RNG state is ever used).

export function hash3(x: number, y: number, z: number, seed: number): number {
  let h = (x | 0) * 374761393 + (y | 0) * 668265263 + (z | 0) * 2147483647 + (seed | 0) * 3266489917;
  h = (h ^ (h >>> 13)) * 1274126177;
  h = h ^ (h >>> 16);
  return ((h >>> 0) % 1_000_000) / 1_000_000; // [0,1)
}

export function hash3s(x: number, y: number, z: number, seed: number): number {
  return hash3(x, y, z, seed) * 2 - 1; // [-1,1)
}

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
