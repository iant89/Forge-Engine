import * as fs from 'fs';
import * as path from 'path';
import { ChunkAddress, ChunkResult } from './chunkGenerator';

export function chunkCacheKey(addr: ChunkAddress): string {
  return `f${addr.face}_${addr.u0.toFixed(6)}_${addr.v0.toFixed(6)}_${addr.u1.toFixed(6)}_${addr.v1.toFixed(6)}_r${addr.resolution}`;
}

export function saveChunk(dir: string, addr: ChunkAddress, chunk: ChunkResult) {
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, chunkCacheKey(addr) + '.bin');
  const header = Buffer.alloc(4);
  header.writeInt32LE(chunk.resolution, 0);
  const parts = [
    header,
    Buffer.from(chunk.positions.buffer, chunk.positions.byteOffset, chunk.positions.byteLength),
    Buffer.from(chunk.heights.buffer, chunk.heights.byteOffset, chunk.heights.byteLength),
    Buffer.from(chunk.materials.buffer, chunk.materials.byteOffset, chunk.materials.byteLength),
    Buffer.from(chunk.slope.buffer, chunk.slope.byteOffset, chunk.slope.byteLength),
  ];
  fs.writeFileSync(file, Buffer.concat(parts));
}

export function chunkExists(dir: string, addr: ChunkAddress): boolean {
  return fs.existsSync(path.join(dir, chunkCacheKey(addr) + '.bin'));
}

// Every field is read via ArrayBuffer#slice(start,end), which always copies into a *fresh*,
// zero-offset buffer — so constructing a Float32Array view on the result is always safely
// aligned, regardless of where that field happened to start inside the packed file.
export function loadChunk(dir: string, addr: ChunkAddress): ChunkResult {
  const file = path.join(dir, chunkCacheKey(addr) + '.bin');
  const buf = fs.readFileSync(file);
  const base = buf.byteOffset;
  const ab = buf.buffer;

  const n = buf.readInt32LE(0);
  let off = 4;

  const nextF32 = (count: number) => {
    const bytes = count * 4;
    const arr = new Float32Array(ab.slice(base + off, base + off + bytes));
    off += bytes;
    return arr;
  };
  const nextU8 = (count: number) => {
    const arr = new Uint8Array(ab.slice(base + off, base + off + count));
    off += count;
    return arr;
  };

  const positions = nextF32(n * n * 3);
  const heights = nextF32(n * n);
  const materials = nextU8(n * n);
  const slope = nextF32(n * n);

  return { resolution: n, positions, heights, materials, slope };
}
