import { Vec3, scale } from '../utils/vec3';
import { faceUVToDirection } from '../cubeSphere';
import { sampleAnalytic, WorldGenParams } from '../terrain/analyticBase';
import { sampleGlobalFields } from '../global/sampleGlobal';
import { GlobalFaceFields } from '../global/stageA';
import { fbm3, ridged3 } from '../noise/gradient3';

export interface ChunkAddress { face: number; u0: number; v0: number; u1: number; v1: number; resolution: number; }

export interface ChunkResult {
  resolution: number;
  positions: Float32Array; // resolution*resolution*3, planet-space meters (see README re: GPU precision)
  heights: Float32Array;   // resolution*resolution, elevation above the reference sphere (meters)
  materials: Uint8Array;
  slope: Float32Array;     // simple grid-space slope estimate, for material blending / debugging
}

// Meso/micro/very-fine detail layered on top of the interpolated simulated-erosion field.
// Amplitude and character are modulated by geology, not applied uniformly: softer rock gets
// taller, smoother gully-like ridges; harder rock gets shorter but sharper exposed-rock texture;
// high flow accumulation (channelized terrain) boosts the small-scale texture further.
function fineDetail(dir: Vec3, radius: number, hardness: number, flowAccum: number, seed: number): number {
  const p = scale(dir, radius);
  const meso = fbm3(p.x * 0.001, p.y * 0.001, p.z * 0.001, { octaves: 5, lacunarity: 2.0, gain: 0.5, frequency: 1, seed: seed + 201 });
  const micro = ridged3(p.x * 0.02, p.y * 0.02, p.z * 0.02, { octaves: 4, lacunarity: 2.2, gain: 0.5, frequency: 1, seed: seed + 301 });
  const veryFine = fbm3(p.x * 0.6, p.y * 0.6, p.z * 0.6, { octaves: 3, lacunarity: 2.3, gain: 0.5, frequency: 1, seed: seed + 401 });

  const softAmp = 4 + (1 - hardness) * 10;
  const microAmp = 0.6 + hardness * 2.2;
  const channelBoost = 1 + Math.min(2, flowAccum * 0.001);

  return meso * softAmp + (micro - 0.5) * 2 * microAmp * channelBoost + veryFine * 0.35;
}

// Deterministic, stateless: same (addr, params, cached global faces) always produces the same
// chunk, and neighboring chunks/LODs agree exactly along shared edges because every vertex is
// evaluated from its absolute world direction rather than from any chunk-local index.
export function generateChunk(addr: ChunkAddress, params: WorldGenParams, globalFaces: GlobalFaceFields[]): ChunkResult {
  const n = addr.resolution;
  const positions = new Float32Array(n * n * 3);
  const heights = new Float32Array(n * n);
  const materials = new Uint8Array(n * n);
  const slope = new Float32Array(n * n);

  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const u = addr.u0 + (addr.u1 - addr.u0) * (i / (n - 1));
      const v = addr.v0 + (addr.v1 - addr.v0) * (j / (n - 1));
      const dir = faceUVToDirection(addr.face, u, v);

      const analytic = sampleAnalytic(dir, params);
      const g = sampleGlobalFields(dir, globalFaces);
      const detail = fineDetail(dir, params.radius, analytic.hardness, g.flowAccum, params.seed);

      const elevation = analytic.elevation + g.erosionDelta + detail;
      const idx = j * n + i;
      heights[idx] = elevation;
      materials[idx] = g.material as number;

      const worldPos = scale(dir, params.radius + elevation);
      positions[idx * 3 + 0] = worldPos.x;
      positions[idx * 3 + 1] = worldPos.y;
      positions[idx * 3 + 2] = worldPos.z;
    }
  }

  // Cheap grid-space slope estimate for material blending/debug; the renderer should compute real
  // per-vertex normals from `positions` for lighting (see README).
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const idx = j * n + i;
      const hl = heights[j * n + Math.max(0, i - 1)], hr = heights[j * n + Math.min(n - 1, i + 1)];
      const hd = heights[Math.max(0, j - 1) * n + i], hu = heights[Math.min(n - 1, j + 1) * n + i];
      slope[idx] = (Math.abs(hr - hl) + Math.abs(hu - hd)) * 0.5;
    }
  }

  return { resolution: n, positions, heights, materials, slope };
}
