import * as path from 'path';
import * as fs from 'fs';
import { runStageAForFace, GlobalFaceFields } from './global/stageA';
import { saveGlobalFace, loadGlobalFace } from './global/globalCache';
import { generateChunk, ChunkAddress } from './chunk/chunkGenerator';
import { saveChunk, chunkExists } from './chunk/chunkCache';
import { marsParams, stageAOptions } from './config/marsConfig';

// This whole file is the "generation utility" meant to run at development time: run Stage A once
// to simulate+cache the low-res global erosion fields, then walk a quadtree of chunks and cache
// each one. The running game only ever reads the resulting cache/ directory — see README.

const OUT_DIR = path.join(__dirname, '..', 'cache');
const GLOBAL_DIR = path.join(OUT_DIR, 'global');
const CHUNK_DIR = path.join(OUT_DIR, 'chunks');

function buildStageA(): GlobalFaceFields[] {
  const faces: GlobalFaceFields[] = [];
  for (let face = 0; face < 6; face++) {
    console.log(`[stageA] generating face ${face}...`);
    const f = runStageAForFace(face, marsParams, stageAOptions);
    saveGlobalFace(GLOBAL_DIR, f);
    faces.push(f);
  }
  return faces;
}

function loadStageA(): GlobalFaceFields[] {
  const faces: GlobalFaceFields[] = [];
  for (let face = 0; face < 6; face++) faces.push(loadGlobalFace(GLOBAL_DIR, face));
  return faces;
}

// Iterates a simple fixed-depth quadtree of chunks per face and caches each one that doesn't
// already exist. In the running engine, chunk requests would instead be driven by the
// streaming/LOD system based on camera distance; this function exists purely to pre-warm the
// on-disk cache for a chosen area/depth during development.
function buildChunks(faces: GlobalFaceFields[], quadDepth: number, chunkResolution: number) {
  const divisions = 2 ** quadDepth;
  const step = 2 / divisions;
  let count = 0;
  for (let face = 0; face < 6; face++) {
    for (let jy = 0; jy < divisions; jy++) {
      for (let ix = 0; ix < divisions; ix++) {
        const addr: ChunkAddress = {
          face,
          u0: -1 + ix * step, u1: -1 + (ix + 1) * step,
          v0: -1 + jy * step, v1: -1 + (jy + 1) * step,
          resolution: chunkResolution,
        };
        if (chunkExists(CHUNK_DIR, addr)) continue;
        const chunk = generateChunk(addr, marsParams, faces);
        saveChunk(CHUNK_DIR, addr, chunk);
        count++;
        if (count % 50 === 0) console.log(`[chunks] cached ${count}...`);
      }
    }
  }
  console.log(`[chunks] done, cached ${count} new chunk(s).`);
}

function main() {
  const args = process.argv.slice(2);
  const mode = args[0] || 'all'; // 'all' | 'stageA' | 'chunks'
  fs.mkdirSync(OUT_DIR, { recursive: true });

  let faces: GlobalFaceFields[];
  if (mode === 'stageA' || mode === 'all') {
    faces = buildStageA();
  } else {
    faces = loadStageA();
  }

  if (mode === 'chunks' || mode === 'all') {
    const depth = Number(args[1] ?? 4);      // 2^depth x 2^depth chunks per face
    const resolution = Number(args[2] ?? 65); // vertices per chunk edge
    buildChunks(faces, depth, resolution);
  }
}

main();
