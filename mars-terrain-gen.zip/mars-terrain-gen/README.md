# mars-terrain-gen

A deterministic, chunked, **dev-time** procedural terrain generator for a whole-planet Mars-style
game world, meant to be run offline to populate a cache that your WebGPU engine loads at runtime.
Type-checks cleanly under `tsc --strict` (verified in this build); not run through a full
`npm install` here — see **Running it** below.

## Why this scope, and not the full 43-section spec

The spec you pasted is close to a multi-person, multi-month terrain R&D effort (full hydraulic
sediment transport, glacial simulation, karst/limestone caves, full stratigraphy, biome-driven
vegetation, LOD skirting, debug visualization modes for a dozen fields, etc.). I couldn't build
all of it in one pass, so I prioritized the architecture and the pieces that matter most for
**Mars specifically** — which the generic spec doesn't mention at all, but which dominate what
real Mars terrain looks like:

- **Impact craters at multiple size scales** — arguably *the* defining Mars surface feature, and
  entirely absent from the spec you gave me.
- **A crustal dichotomy** (smooth young northern lowlands vs. ancient cratered southern
  highlands) standing in for the spec's "tectonic uplift," since Mars has no plate tectonics.
- **A named shield volcano** (Olympus-Mons-style) and a rift-canyon system (Valles-Marineris-style).
- **Wind (aeolian) erosion as the dominant *active* process**, since Mars is currently dry — the
  spec's hydraulic erosion is instead treated as *frozen ancient hydrology* (a one-time carve, not
  a rainfall loop).

What's implemented is a complete, working pipeline end-to-end (you can run it and get real cached
chunks out), not a stub. What's simplified is noted inline in code comments and summarized below.

## Architecture

```
Stage A (per cube face, low-res, simulated, cached once)
  analytic base (dichotomy + craters + volcanoes + regional fbm)
        -> thermal erosion (talus/repose-angle relaxation)
        -> D8 flow accumulation + one-time hydraulic incision ("ancient" channels)
        -> wind/dune pass
        -> erosionDelta = eroded - base   [this is the only thing Stage B needs from here]

Stage B (per chunk, any resolution, deterministic, on demand or pre-warmed)
  analytic base, evaluated directly at full chunk resolution
        + erosionDelta, bilinear-sampled from Stage A's cached grid
        + meso/micro/very-fine analytic detail, modulated by hardness & flow accumulation
        = final heightmap + material map + positions, written to cache/chunks/*.bin
```

The key idea: craters, volcanoes, and the dichotomy are **analytic** (pure functions of a 3D point
on the sphere — no neighbor lookups needed), so they can be evaluated directly at whatever
resolution a chunk needs, with no upscaling artifacts. **Erosion is not analytic** — it's a
grid-relaxation process — so it's simulated once on a bounded low-res grid per cube face and
cached; chunks interpolate that low-res *correction* field rather than re-simulating anything.

### Planet parameterization: cube-sphere, not lat/long

World positions are 3D points on a sphere, addressed via a 6-face cube-sphere (`src/cubeSphere.ts`),
not an equirectangular (lat/long) grid. Lat/long has pole singularities and heavy area distortion
near the poles — unacceptable for a game world you can actually fly/drive to the poles of. All
noise is sampled in 3D (`src/noise/gradient3.ts`), which is inherently seamless across cube-face
boundaries (no 2D-projection seam-matching tricks needed).

### Determinism & seamlessness

Every sample — in Stage A or Stage B, at any chunk/LOD — is evaluated from the vertex's **absolute
3D world direction**, never from a chunk-local index or per-chunk RNG. Same seed + same world
position always produces the same result, so adjacent chunks (and the same chunk regenerated
later) match exactly along their shared edges.

## What's simplified (and how you'd extend it)

- **Hydrology** is a single D8 flow-accumulation + incision pass standing in for a full
  rainfall/sediment-transport simulation (spec §6, §8). Good enough for dry, ancient-looking
  outflow channels; not a real evolving river system. A fuller version would track sediment mass
  per cell and deposit it downstream (alluvial fans, deltas — spec §18–19) instead of just
  carving.
- **Wind erosion** (`src/erosion/wind.ts`) uses one fixed global wind direction and a dune-noise
  bump; no windward-strip/leeward-deposit directional asymmetry, no multiple wind regimes.
- **Stratification** (spec §10, visible rock layers in canyon/cliff faces) isn't modeled — canyon
  walls currently use one material based on depth, not a layered stack. This is the highest-value
  next addition for visual quality if you want canyon walls to look "geological."
- **Volcanoes are hand-placed data**, not procedurally scattered from a simulated mantle-plume
  field — appropriate for a handful of named features like Olympus Mons, not for generating an
  arbitrary number of them.
- **LOD seams**: `build.ts`'s quadtree walker caches every chunk at one fixed depth/resolution.
  If your engine streams different LODs for near/far chunks, adjacent chunks at different
  resolutions will show T-junction cracks unless you add mesh skirts or a CDLOD-style
  vertex-snapping scheme (spec §32–33) — not implemented here.
- **Performance**: crater sampling checks up to 27 grid cells × 3 size bands per point
  (`src/geology/craters3.ts`). Fine for this dev-time tool; if you push chunk resolution or
  quadtree depth way up, the next optimization is spatial pre-filtering (skip size bands whose
  cell size is much larger than the chunk) or porting Stage A's simulation to a WebGPU compute
  shader for much higher-res erosion.
- **No debug field export** (spec §43 asks for inspectable elevation/slope/geology/etc. layers).
  Every intermediate field already exists as a named `Float32Array`/`Uint8Array` in
  `GlobalFaceFields` and `ChunkResult` — wiring one of them up as a grayscale PNG per field would
  be a small addition, not a redesign.

## Running it

This was type-checked here with `tsc --strict` against a minimal offline shim for Node's built-ins
(no network access in this environment to fetch `@types/node`). In your own environment:

```bash
npm install                 # pulls in typescript, ts-node, @types/node
npm run generate             # Stage A (all 6 faces) + a depth-4 chunk pre-warm, ~65 verts/edge
# or, separately:
npm run generate:stageA
npm run generate:chunks      # edit the depth/resolution args in package.json to taste
```

Output lands in `cache/global/face_<0-5>/*` (Stage A fields) and `cache/chunks/*.bin` (chunk
tiles). Re-running is incremental — `chunkExists` skips chunks already on disk.

## Loading a cached chunk into your WebGPU engine

`chunk/chunkCache.ts`'s `loadChunk()` gives you back `{ positions, heights, materials, slope }` as
typed arrays — decode once at chunk-load time, no procedural generation needed at runtime. Two
things worth doing on the way to a vertex buffer:

1. **Re-center for float32 precision.** `positions` are absolute planet-space meters (~3.39e6 m
   magnitude for Mars). That's fine in the JS `Float64` math used to generate it, but uploading
   `Float32Array` values that large straight to a GPU vertex buffer will show visible jitter at
   close range. Subtract the chunk's centroid (or camera-relative origin) before upload, and keep
   the offset on the CPU side for placing the chunk's model matrix.
2. **Compute real normals** from `positions` (cross-product of local tangent vectors per grid
   quad) rather than using the `slope` field for lighting — `slope` is a cheap scalar meant for
   material-blend weighting/debugging, not shading.

`materials` values are the `GeoMaterial` enum from `src/geology/materials.ts` — use it as an index
into a texture array or splat-map blend in your terrain shader.
